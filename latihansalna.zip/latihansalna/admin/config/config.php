<?php

define('baseurl', 'http://localhost/latihansalna/public');

